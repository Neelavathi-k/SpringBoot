package com.ibm.smt.payment.dto;

public class PaymentRequest {

	 private int userid;
	 private String itemid;
	 private double discount;

	 public String getitemid() {
	  return itemid;
	 }

	 public void setitemid(String itemid) {
	  this.itemid = itemid;
	 }

	 public double getdiscount() {
	  return discount;
	 }

	 public void setdiscount(double discount) {
	  this.discount = discount;
	 }

	 public int getuserid() {
	  return userid;
	 }

	 public void setuserid(int userid) {
	  this.userid = userid;
	 }

	}