package com.ibm.smt.payment.dto;

public class BaseResponse {

	 private String status;
	 private Integer code;

	 public String getstatus() {
	  return status;
	 }

	 public void setstatus(String status) {
	  this.status = status;
	 }

	 public Integer getcode() {
	  return code;
	 }

	 public void setcode(Integer code) {
	  this.code = code;
	 }

	}