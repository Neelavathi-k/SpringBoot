package com.ibm.smt.payment.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.smt.payment.dto.BaseResponse;
import com.ibm.smt.payment.dto.PaymentRequest;

public class PaymentController {

	@RestController //annotation in order to simplify the creation of RESTful web services.(https://www.baeldung.com/spring-controller-vs-restcontroller)
	@RequestMapping("/payment") //annotation is used to map web requests to Spring Controller methods.(https://www.baeldung.com/spring-requestmapping)
	public class paymentcontroller {
		
		 private final String sharedkey = "shared_key";
		 private static final String success_status = "success";
		 private static final String error_status = "error";
		 private static final int code_success = 100;
		 private static final int auth_failure = 102;
		 
		@RequestMapping(value = "/pay", method = RequestMethod.POST)
		 public BaseResponse pay(@RequestParam(value = "key") String key, @RequestBody PaymentRequest request) {

			System.out.println("key :: " + key);
			  BaseResponse response = new BaseResponse();
			  if (sharedkey.equalsIgnoreCase(key)) {
			   int userid = request.getuserid();
			   String itemid = request.getitemid();
			   double discount = request.getdiscount();
	
			   // process the request
			   // ....
			   // return success response to the client.
	
			   response.setstatus(success_status);
			   response.setcode(code_success);
			  } else {
			   response.setstatus(error_status);
			   response.setcode(auth_failure);
			  }
			  return response;
			 }
		}
}
