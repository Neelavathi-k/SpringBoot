package com.batch.spring.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.batch.spring.listener.FirstJobListener;
import com.batch.spring.listener.FirstStepListener;
import com.batch.spring.processor.FirstItemProcessor;
import com.batch.spring.reader.FirstItemReader;
import com.batch.spring.service.CustomTasklet;
import com.batch.spring.writer.FirstItemWriter;

@Configuration
public class BatchConfig {

	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private CustomTasklet customTasklet;
	
	@Autowired
	private FirstJobListener firstJobListener;
	
	@Autowired
	private FirstStepListener firstStepListener;
	
	@Autowired
	private FirstItemReader firstItemReader;
	
	@Autowired
	private FirstItemProcessor firstItemProcessor;
	
	@Autowired
	private FirstItemWriter firstItemWriter;
	
	@Bean
	public Job firstJob() {
		return jobBuilderFactory.get("First Job")
				.start(firstStep())
				.next(secondStep())
				.next(customTasklet())
				.listener(firstJobListener)
				.build();
	}
	
	public Step firstStep() {
		return stepBuilderFactory.get("first Step")
				.tasklet(firstTask())
				.listener(firstStepListener)
				.build();
	}
	
	public Step secondStep() {
		return stepBuilderFactory.get("second Step")
				.tasklet(secondTask())
				.build();
	}
	
	public Step customTasklet() {
		return stepBuilderFactory.get("customTasklet")
				.tasklet(customTasklet)
				.build();
	}
	
//	@Bean
	public Tasklet firstTask() {
		return new Tasklet() {
			@Override
			public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
				
				System.out.println("This is my first tasklet.");
				return RepeatStatus.FINISHED;
			}
		};
	}
	
	public Tasklet secondTask() {
		return new Tasklet() {
			@Override
			public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
				
				System.out.println("This is my second tasklet.");
				return RepeatStatus.FINISHED;
			}
		};
	}
	
	@Bean
	public Job secondJob() {
		return jobBuilderFactory.get("Second Job")
				.incrementer(new RunIdIncrementer())
				.start(firstChunkStep())
				.next(customTasklet())
				.build();
	}
	
	public Step firstChunkStep() {
		return stepBuilderFactory.get("First Chunk Step")
				.<Integer, Integer>chunk(3)
				.reader(firstItemReader)
//				.processor(firstItemProcessor)
				.writer(firstItemWriter)
				.build();
	}
	
}
