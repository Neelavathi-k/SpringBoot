package com.batch.spring.listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.stereotype.Component;

@Component
public class FirstStepListener implements StepExecutionListener{

	@Override
	public void beforeStep(StepExecution stepExecution) {
		System.out.println(":: Before Step ::");
		System.out.println("Step Name :: " + stepExecution.getStepName());
		System.out.println("Step Execution Context :: " + stepExecution.getExecutionContext());
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		System.out.println(":: After Step ::");
		System.out.println("Step Name :: " + stepExecution.getStepName());
		System.out.println("Step Execution Context :: " + stepExecution.getExecutionContext());
		return null;
	}

}
