package com.batch.spring.SpringBatch01;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableBatchProcessing
@ComponentScan("com.batch.spring")
public class SpringBatch01Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatch01Application.class, args);
	}

}
