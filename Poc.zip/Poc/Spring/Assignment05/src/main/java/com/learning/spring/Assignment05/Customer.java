package com.learning.spring.Assignment05;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer {
	
	private String customerName;
	@Autowired
	private Reservation reservation;
	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

	@Override
	public String toString() {
		return "Customer [customerName=" + customerName + ", reservation=" + reservation + "]";
	}
}
