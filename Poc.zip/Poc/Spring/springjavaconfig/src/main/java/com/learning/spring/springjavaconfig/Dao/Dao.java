package com.learning.spring.springjavaconfig.Dao;

import org.springframework.stereotype.Component;

@Component
public class Dao {

	public void create() {
		System.out.println("Inside the create method From DAO class");
	}
}
