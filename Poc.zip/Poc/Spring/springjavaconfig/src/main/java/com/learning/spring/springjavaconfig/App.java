package com.learning.spring.springjavaconfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.learning.spring.springjavaconfig.service.Service;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		Service service = context.getBean(Service.class);
//		service.create();
		System.out.println(service.hashCode());
		
		Service service1 = context.getBean(Service.class);
		System.out.println(service1.hashCode());
	}
}
