package com.learning.spring.springjavaconfig.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;

import com.learning.spring.springjavaconfig.Dao.Dao;

//@Scope("prototype")
public class Service {

	@Autowired
	private Dao dao;
	
	public void create() {
		dao.create();
	}
}
