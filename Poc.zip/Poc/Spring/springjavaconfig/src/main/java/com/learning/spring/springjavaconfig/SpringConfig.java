package com.learning.spring.springjavaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;

import com.learning.spring.springjavaconfig.Dao.DaoConfig;
import com.learning.spring.springjavaconfig.service.Service;

@Configuration
@Import(DaoConfig.class)
//@Import(ServiceConfig.class)
public class SpringConfig {

	@Bean
	@Scope("prototype")
	public Service Service() {
		return new Service();
	}

}
