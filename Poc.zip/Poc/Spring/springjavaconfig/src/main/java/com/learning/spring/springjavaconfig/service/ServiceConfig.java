package com.learning.spring.springjavaconfig.service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServiceConfig {

	@Bean
	public Service Service() {
		return new Service();
	}
}
