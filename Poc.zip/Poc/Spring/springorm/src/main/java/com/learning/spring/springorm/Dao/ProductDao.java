package com.learning.spring.springorm.Dao;

import com.learning.spring.springorm.entity.Product;

public interface ProductDao {

	int create(Product product);
	int update(Product product);
	void delete(Product product);
}
