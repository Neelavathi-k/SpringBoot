package com.learning.spring.springorm;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.learning.spring.springorm.Dao.ProductDao;
import com.learning.spring.springorm.entity.Product;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
       ProductDao productDao = context.getBean(ProductDao.class);
       Product product = new Product();
       product.setId(001);
       product.setName("Kurthi");
       product.setDesc("Awesome");
       product.setPrice(1200);
//       productDao.create(product);
//       productDao.update(product);
       productDao.delete(product);
       
       
    }
}
