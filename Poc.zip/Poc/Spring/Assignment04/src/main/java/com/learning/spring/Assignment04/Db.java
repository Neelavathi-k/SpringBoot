package com.learning.spring.Assignment04;

public class Db {

	private String url;
	private String userName;
	private String password;

	public Db(String url, String userName, String password) {
		this.url = url;
		this.userName = userName;
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "Db [url=" + url + ", userName=" + userName + ", password=" + password + "]";
	}

}
