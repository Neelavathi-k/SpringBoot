package com.learning.spring.Assignment02;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
        TicketReservation ticket = (TicketReservation)context.getBean("ticket");
        context.registerShutdownHook();
    }
}
