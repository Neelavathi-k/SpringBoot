package com.learning.spring.springcoreadvanced.injecting.interfaces;

public interface OrderBo {

	void placeOrder();
}
