package com.learning.spring.springcoreadvanced.injecting.interfaces;

public interface OrderDao {
	void createOrder();
}
