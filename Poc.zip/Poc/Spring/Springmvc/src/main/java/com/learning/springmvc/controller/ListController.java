package com.learning.springmvc.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.learning.springmvc.dto.Employee;

@Controller
public class ListController {

	@RequestMapping("/sendList")
	public ModelAndView sendList() {
		
		ModelAndView modelAndView = new ModelAndView();
		ArrayList<Employee> employeeList = new ArrayList<Employee>();
		Employee employee = new Employee();
		employee.setId(001);
		employee.setName("Neelavathi");
		employee.setSalary(10000);
		employeeList.add(employee);
		
		employee = new Employee();
		employee.setId(002);
		employee.setName("Neelavathi K");
		employee.setSalary(20000);
		employeeList.add(employee);
		
		employee = new Employee();
		employee.setId(003);
		employee.setName("Neela");
		employee.setSalary(30000);
		employeeList.add(employee);
		
		for(Employee emp: employeeList) {
			System.out.println(emp.getId() + " - " + emp.getName() + " - " + emp.getSalary());
		}
		
		modelAndView.addObject("employeeList", employeeList);
		modelAndView.setViewName("displayList");
		return modelAndView;
	}
}
