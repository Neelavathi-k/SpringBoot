package com.learning.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.learning.springmvc.dto.Employee;

@Controller
public class ObjectController {

	@RequestMapping("/sendObject")
	public ModelAndView sendObject() {

		ModelAndView modelAndView = new ModelAndView();
		Employee employee = new Employee();
		employee.setId(002);
		employee.setName("Neela");
		employee.setSalary(200000);
		modelAndView.addObject("employee", employee);
		modelAndView.setViewName("displayObject");
		return modelAndView;
	}
}
