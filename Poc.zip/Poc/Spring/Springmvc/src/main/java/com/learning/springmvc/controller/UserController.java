package com.learning.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.learning.springmvc.dto.User;

@Controller
public class UserController {

//	@RequestMapping("/userReg")
//	public ModelAndView userReg() {
//		return new ModelAndView("userReg");
//	}
	
	@RequestMapping("/userReg")
	public String userReg() {
		return "userReg";
	}
	
//	@RequestMapping(value="/userRegistration", method=RequestMethod.POST)
//	public ModelAndView userRegistration(@ModelAttribute("user") User user) {
//		System.out.println(user);
//		ModelAndView modelAndView = new ModelAndView();
//		modelAndView.addObject("user", user);
//		modelAndView.setViewName("userResult");		
//		return modelAndView;
//	}
	
	@RequestMapping(value="/userRegistration", method=RequestMethod.POST)
	public String userRegistration(@ModelAttribute("user") User user, ModelMap modelMap) {
		System.out.println(user);
		modelMap.addAttribute("user", user);
		return "userResult";
	}
}
