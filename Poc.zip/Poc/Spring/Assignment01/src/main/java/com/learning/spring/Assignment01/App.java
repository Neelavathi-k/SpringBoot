package com.learning.spring.Assignment01;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.learning.spring.Assignment01.pojo.ShoppingCart;

public class App {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		ShoppingCart shoppingCart = (ShoppingCart)context.getBean("cart");
		System.out.println(shoppingCart.getItem());
		System.out.println(shoppingCart.getItem().toString());
	}
}
