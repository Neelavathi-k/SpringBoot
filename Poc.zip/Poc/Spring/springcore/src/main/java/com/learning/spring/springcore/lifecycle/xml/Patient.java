package com.learning.spring.springcore.lifecycle.xml;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Patient { // implements InitializingBean, DisposableBean {  <!-- Call lifecycle methods through spring Interface-->

	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		System.out.println("Inside patient id setter method.");
		this.id = id;
	}

	public void initialMethod() {
		System.out.println("Hi we are inside init() method");
	}

	public void destroyMethod() {
		System.out.println("Hi we are inside destroy() method");
	}

	@Override
	public String toString() {
		return "Patient [id=" + id + "]";
	}

//	Call lifecycle methods through spring Interface
	/*@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Inside afterPropertiesSet()");

	}

	@Override
	public void destroy() throws Exception {
		System.out.println("Inside destroy()");

	}*/
	
	@PostConstruct
	public void init() {
		System.out.println("init method");
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("destroy method");
	}
}
