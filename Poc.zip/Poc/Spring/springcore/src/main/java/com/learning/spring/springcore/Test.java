package com.learning.spring.springcore;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.learning.spring.springcore.dependencycheck.Prescription;

public class Test {

	public static void main(String[] args) {

//		AbstractApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
//		Employee employee = (Employee) ctx.getBean("emp");
//		System.out.println("Employee ID : " + employee.getId());
//		System.out.println("Employee Name : " + employee.getName());
//
//		Hospital hospital = (Hospital) ctx.getBean("hosp");
//		System.out.println("Hospital Name : " + hospital.getName());
//		System.out.println("department size in hospital :: " + hospital.getDepartment());
//
//		CarDealer car = (CarDealer) ctx.getBean("car");
//		System.out.println("Car dealer name :: " + car.getName());
//		System.out.println("Car Models :: " + car.getModel());
//		
//		System.out.println("===============================================================================================");
//		Patient patient = (Patient)ctx.getBean("patient");
//		System.out.println(patient);
//		ctx.registerShutdownHook();

		/* Dependency Check - making injecting dependency mandate using @required */
		ApplicationContext context  = new ClassPathXmlApplicationContext("spring.xml");
//		Prescription prescription = (Prescription)context.getBean("prescription");
//		System.out.println(prescription);
		
		/* Inner Bean */
		com.learning.spring.springcore.innerBean.Employee employee = (com.learning.spring.springcore.innerBean.Employee)context.getBean("employee");
		System.out.println(employee.hashCode());
		
		com.learning.spring.springcore.innerBean.Employee employees = (com.learning.spring.springcore.innerBean.Employee)context.getBean("employee");
		System.out.println(employees.hashCode());
		
	}
}
