package com.learning.spring.Assignment03;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		University university = (University) context.getBean("university");
		System.out.println(university);

		System.out.println(university.hashCode());
		University university1 = (University) context.getBean("university");
		System.out.println(university1.hashCode());
	}
}
