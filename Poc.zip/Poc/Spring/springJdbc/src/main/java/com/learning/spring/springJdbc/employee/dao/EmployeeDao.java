package com.learning.spring.springJdbc.employee.dao;

import java.util.List;

import com.learning.spring.springJdbc.employee.dto.Employee;

public interface EmployeeDao {

	int create(Employee employee);
	int update(Employee employee);
	int delete(Employee employee);
	Employee read(int id);
	List<Employee> readEmployees();
}
