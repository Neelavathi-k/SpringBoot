package com.learning.spring.springJdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.learning.spring.springJdbc.employee.dao.EmployeeDaoImpl;
import com.learning.spring.springJdbc.employee.dto.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("spring.xml");
//		JdbcTemplate jdbcTemplte = (JdbcTemplate) ctx.getBean("jT");
//		String query = "INSERT INTO EMPLOYEE(id,firstname,lastname) VALUES (?,?,?)";
//		int result = jdbcTemplte.update(query, 1, "Neelavathi", "K");
		
		EmployeeDaoImpl employee = (EmployeeDaoImpl) ctx.getBean("employeeDaoImpl");
		
//		Employee emp = new Employee();
//		emp.setId(2);
//		emp.setFirstName("Suhasini");
//		emp.setLastName("H.S.");
//		System.out.println(employee.create(emp));
//		System.out.println(employee.update(emp));
//		System.out.println(employee.delete(emp));
//		Employee emp = employee.read(1);
//		System.out.println(emp.toString());
		
		List<Employee> employeeList = employee.readEmployees();
		for(Employee empList : employeeList) {
			System.out.println(empList.toString());
		}
	}
}
