package com.learning.spring.springJdbc.employee.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.learning.spring.springJdbc.employee.dto.Employee;
import com.learning.spring.springJdbc.employee.rowmapper.EmployeeRowMapper;

@Component
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

//	public JdbcTemplate getJdbcTemplate() {
//		return jdbcTemplate;
//	}
//
//	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
//		this.jdbcTemplate = jdbcTemplate;
//	}

	@Override
	public int create(Employee employee) {
		String query = "INSERT INTO EMPLOYEE(id,firstname,lastname) VALUES (?,?,?)";
		return jdbcTemplate.update(query, employee.getId(), employee.getFirstName(), employee.getLastName());
	}

	@Override
	public int update(Employee employee) {
		String updateQuery = "UPDATE employee SET firstname = ?, lastname = ? WHERE id = ?";
		return jdbcTemplate.update(updateQuery, employee.getFirstName(), employee.getLastName(), employee.getId());
	}

	@Override
	public int delete(Employee employee) {
		String deleteQuery = "DELETE from employee WHERE id = ?";
		return jdbcTemplate.update(deleteQuery, employee.getId());
	}

	@Override
	public Employee read(int id) {
		String query = "SELECT * FROM EMPLOYEE WHERE id = ?";
		return jdbcTemplate.queryForObject(query, new EmployeeRowMapper(), id);
	}
	
	@Override
	public List<Employee> readEmployees() {
		String query = "SELECT * FROM EMPLOYEE";
		return jdbcTemplate.query(query, new EmployeeRowMapper());
	}
}
