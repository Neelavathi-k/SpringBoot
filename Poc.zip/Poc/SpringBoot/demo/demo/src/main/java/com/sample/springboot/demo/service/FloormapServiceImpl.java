package com.sample.springboot.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sample.springboot.demo.dao.FloormapDaoImpl;
import com.sample.springboot.demo.dto.FloormapDto;

@Service
public class FloormapServiceImpl {

	@Autowired
	FloormapDaoImpl daoImpl;
	
	public List getAccountwiseAllocatedSeats(FloormapDto mapVo) {
		
		List<FloormapDto> mapDOList = daoImpl.getAccountwiseAllocatedSeats(mapVo);
		
		ArrayList legendslist = new ArrayList();
		ArrayList<FloormapDto> availableList = new ArrayList<FloormapDto>();
		ArrayList<FloormapDto> accountList = new ArrayList<FloormapDto>();
		ArrayList<FloormapDto> deptList = new ArrayList<FloormapDto>();
		ArrayList<FloormapDto> loanedoutList = new ArrayList<FloormapDto>();
		
		for(FloormapDto bean:mapDOList){
			if(null != bean.getAccount()){
				if(("AVAILABLE SEATS").equalsIgnoreCase(bean.getAccount())){
					availableList.add(bean);
				}else if(("LOANED-OUT SEATS").equalsIgnoreCase(bean.getAccount())){
					loanedoutList.add(bean);
				}else if(("DEPARTMENT SEATS").equalsIgnoreCase(bean.getAccount())){
					deptList.add(bean);
				}else{
					accountList.add(bean);
				}
			} else {
				accountList.add(bean);
			}
		
		}
		
		for(int k=0; k<availableList.size(); k++){
			legendslist.add(availableList.get(k));
		}
		
		for(int l=0; l<accountList.size();l++){
			legendslist.add(accountList.get(l));
		}
		
		for(int a=0; a<deptList.size(); a++){
			legendslist.add(deptList.get(a));
		}
		
		for(int b=0; b<loanedoutList.size(); b++){
			legendslist.add(loanedoutList.get(b));
		}

		return legendslist;
	}

}
