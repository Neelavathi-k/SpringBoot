package com.sample.springboot.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sample.springboot.demo.dto.FloormapDto;
import com.sample.springboot.demo.service.FloormapServiceImpl;

@RestController
public class FloormapController {

	@Autowired
	FloormapServiceImpl serviceImpl;
	
	@RequestMapping("/legendlist")
	public List getFloormapLegend(@RequestBody FloormapDto mapDto) {
		return serviceImpl.getAccountwiseAllocatedSeats(mapDto);
	}
}
