package com.sample.springboot.demo.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.sample.springboot.demo.dto.FloormapDto;

@Repository
public class FloormapDaoImpl {

	public static final String ACCOUNTWISE_ALLOCATED_SEATS = "SELECT LISTAGG(CAST(COALESCE(WING.FWING,'') || MASTER.FSEAT_NO AS VARCHAR(10000)),'+*') FLIST, "
			+ "LISTAGG(CAST(COALESCE(WING.FWING,'') || MASTER.FSEAT_NO AS VARCHAR(10000)),',') FLIST1, "
			+ "CASE WHEN SHIFT.FIS_PEM = 'Y' THEN COALESCE(SHIFT.FDEPT_ID,PDEPT1.FDEPT_ID) || '-' ||  COALESCE(PDEPT.FDEPT_NAME ,PDEPT1.FDEPT_NAME) "
			+ "WHEN TRIM(FINVENTORY_TYPE) = 'LOANED-OUT' THEN 'LOANED-OUT SEATS - ' || COALESCE(BU.FBU, 'N/A') "
			+ "WHEN TRIM(FINVENTORY_TYPE) <> 'LOANED-OUT' AND SHIFT.FINVENTORY_ID is NULL THEN 'AVAILABLE SEATS' "
			+ "ELSE ACTDET.FACCOUNT_NAME END as FACCOUNT_NAME , "
			+ "COALESCE(ARUR.FRECOMMENDED_UTILIZ_RATE, DRUR.FRECOMMENDED_UTILIZ_RATE,0) RUR, "
			+ "SEATTYPE.FSEAT_TYPE,NTWTYPE.FNETWORK_TYPE,COUNT(MASTER.FSEAT_NO) AS TOTALSEATS , CAT.FINVENTORY_CAT "
			+ "FROM DB2INST1.TINVENTORY_MASTER MASTER "
			+ "LEFT OUTER JOIN DB2INST1.TINVENTORY_SHIFT_DETAILS SHIFT ON MASTER.FINVENTORY_ID=SHIFT.FINVENTORY_ID "
			+ "INNER JOIN DB2INST1.TPARAM_INVENTORY_TYPE ITYPE ON MASTER.FINVENTORY_TYPE_ID=ITYPE.FINVENTORY_TYPE_ID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_ACCOUNT_DET ACTDET ON ACTDET.FACCOUNT_KEY=SHIFT.FACCOUNT_KEY "
			+ "LEFT JOIN DB2INST1.TPARAM_DEPARTMENT_NONPIR PDEPT1 ON PDEPT1.FDEPT_ID = SHIFT.FDEPT_ID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_SEAT_TYPE SEATTYPE ON SEATTYPE.FSEAT_TYPE_ID=MASTER.FSEAT_TYPE_ID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_NETWORK_TYPE NTWTYPE ON NTWTYPE.FNETWORKTYPE_ID=SHIFT.FNETWORKTYPE_ID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_WING WING ON WING.FWING_ID=MASTER.FWING_ID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_DEPARTMENT PDEPT ON PDEPT.FDEPT_ID = SHIFT.FDEPT_ID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_LOC_UTILIZ_RATE ARUR ON SHIFT.FACCOUNT_KEY = ARUR.FACCOUNT_KEY AND MASTER.FLOCATION_ID = ARUR.FLOCATION_ID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_LOC_UTILIZ_RATE_DEPT DRUR ON SHIFT.FDEPT_ID = DRUR.FDEPT_ID AND MASTER.FLOCATION_ID = DRUR.FLOCATION_ID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_INVENTORY_CAT CAT ON CAT.FINVENTORY_CATID = MASTER.FINVENTORY_CATID "
			+ "LEFT OUTER JOIN DB2INST1.TPARAM_BU BU ON BU.FBU_ID = MASTER.FLOAN_BU_ID  "
			+ "WHERE MASTER.FLOCATION_ID=? AND MASTER.FCAMPUS_ID=? AND MASTER.FBUILDING_ID= ? AND "
			+ "MASTER.FFLOOR_ID= ? GROUP BY CASE WHEN SHIFT.FIS_PEM = 'Y' THEN COALESCE(SHIFT.FDEPT_ID,PDEPT1.FDEPT_ID) || '-' ||  COALESCE(PDEPT.FDEPT_NAME ,PDEPT1.FDEPT_NAME) "
			+ "WHEN TRIM(FINVENTORY_TYPE) = 'LOANED-OUT' THEN 'LOANED-OUT SEATS - ' || COALESCE(BU.FBU, 'N/A')  "
			+ "WHEN TRIM(FINVENTORY_TYPE) <> 'LOANED-OUT' AND SHIFT.FINVENTORY_ID is NULL THEN 'AVAILABLE SEATS' "
			+ "ELSE ACTDET.FACCOUNT_NAME END , "
			+ "COALESCE(ARUR.FRECOMMENDED_UTILIZ_RATE, DRUR.FRECOMMENDED_UTILIZ_RATE,0),SEATTYPE.FSEAT_TYPE,NTWTYPE.FNETWORK_TYPE,CAT.FINVENTORY_CAT ORDER BY TOTALSEATS DESC ";

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<FloormapDto> getAccountwiseAllocatedSeats(FloormapDto mapVo) {

		return jdbcTemplate.query(ACCOUNTWISE_ALLOCATED_SEATS,new Object[] { mapVo.getLocationId(), mapVo.getCampusId(), mapVo.getBuildingId(), mapVo.getFloorId() },new RowMapper<FloormapDto>() {
					public FloormapDto mapRow(ResultSet rs, int row) throws SQLException {

						FloormapDto mapDo = new FloormapDto();

						String[] colorcodes = { "#F18D9E", "#FFBF00", "#A4C639", "#007FFF", "#808000", "#8A2BE2",
								"#FF00FF", "#00FF7F", "#CD7F32", "#FFB7C5", "#FFA700", "#8C92AC", "#B31B1B", "#8B008B",
								"#FF8C00", "#BFFF00", "#7CFC00", "#003f69", "#F4C430", "#FA8072", "#FB7EFD", "#EFCDB8",
								"#FAE7B5", "#FFFF99", "#2B6CC4", "#08E8DE", "#E6D72A", "#FC8EAC", "#C19A6B",
								"#6E0DD0" };

						String colorCode = "";
						if (row > 29) {
							colorCode = getColorCode();
						} else {
							colorCode = colorcodes[row];
						}
						if (rs.getString("FACCOUNT_NAME") != null
								&& rs.getString("FACCOUNT_NAME").equalsIgnoreCase("AVAILABLE SEATS")) {
							colorCode = "#E32636";
						}
						if (rs.getString("FACCOUNT_NAME") != null
								&& rs.getString("FACCOUNT_NAME").startsWith("LOANED-OUT SEATS")) {
							colorCode = "#0EBEA6";
						}

						mapDo.setColorCode(colorCode);
						mapDo.setAccount(rs.getString("FACCOUNT_NAME"));
						mapDo.setTypeOfSeatsName(rs.getString("FSEAT_TYPE"));
						mapDo.setNetworkTypeName(rs.getString("FNETWORK_TYPE"));
						mapDo.setTotalSeatCount(rs.getString("TOTALSEATS"));
						mapDo.setSeatNos(rs.getString("FLIST1"));
						mapDo.setFlist(rs.getString("FLIST"));
						mapDo.setCatofinventoryName(
								rs.getString("FINVENTORY_CAT")); /* Added by Bhagyashri : Inventory_Category */
						mapDo.setRur(rs.getInt("RUR"));

						return mapDo;
					}
				});
	}

	public String getColorCode(){
		String[] letters = new String[15];
	    letters = "0123456789ABCDEF".split("");
	    String code ="#";
	    for(int i=0;i<6;i++)
	    {
	        double ind = Math.random() * 15;
	        int index = (int)Math.round(ind);
	        code += letters[index]; 
	        
	    }
	    if(code.length() == 7){
	    	return code;
	    }else{
	    	return getColorCode();
	    }
	}
}
