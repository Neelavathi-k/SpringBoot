package com.sample.springboot.demo.dto;

import java.util.List;

public class FloormapDto {

	private String colorCode;
	private String account;
	private String typeOfSeatsName;
	private String networkTypeName;
	private String totalSeatCount;
	private String seatNos;
	private String flist;
	private String catofinventoryName;
	private int rur;

	private int locationId;
	private int campusId;
	private int buildingId;
	private int floorId;

	public int getRur() {
		return rur;
	}

	public void setRur(int rur) {
		this.rur = rur;
	}

	public String getColorCode() {
		return colorCode;
	}

	public void setColorCode(String colorCode) {
		this.colorCode = colorCode;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getTypeOfSeatsName() {
		return typeOfSeatsName;
	}

	public void setTypeOfSeatsName(String typeOfSeatsName) {
		this.typeOfSeatsName = typeOfSeatsName;
	}

	public String getNetworkTypeName() {
		return networkTypeName;
	}

	public void setNetworkTypeName(String networkTypeName) {
		this.networkTypeName = networkTypeName;
	}

	public String getTotalSeatCount() {
		return totalSeatCount;
	}

	public void setTotalSeatCount(String totalSeatCount) {
		this.totalSeatCount = totalSeatCount;
	}

	public String getSeatNos() {
		return seatNos;
	}

	public void setSeatNos(String seatNos) {
		this.seatNos = seatNos;
	}

	public String getFlist() {
		return flist;
	}

	public void setFlist(String flist) {
		this.flist = flist;
	}

	public String getCatofinventoryName() {
		return catofinventoryName;
	}

	public void setCatofinventoryName(String catofinventoryName) {
		this.catofinventoryName = catofinventoryName;
	}

	public int getCampusId() {
		return campusId;
	}

	public void setCampusId(int campusId) {
		this.campusId = campusId;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public int getFloorId() {
		return floorId;
	}

	public void setFloorId(int floorId) {
		this.floorId = floorId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

	public int getLocationId() {
		return locationId;
	}

}
